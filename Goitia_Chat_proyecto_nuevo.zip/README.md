# Goitia Chat — prototipo Android

## Requisitos
- Flutter SDK y Android Studio con Android SDK.
- Dos dispositivos Android (o un dispositivo y un emulador con cámara/micrófono).
- Proyecto Firebase con Authentication (Email/Password), Cloud Firestore y Cloud Storage habilitados.

## Instalación
1. En una terminal ejecuta `flutter create --platforms=android goitia_chat` para generar los archivos nativos Android.
2. Copia `lib/main.dart` y `pubspec.yaml` de esta entrega sobre los del proyecto generado.
3. En Firebase Console crea una aplicación Android con el mismo `applicationId` que el proyecto Android. Descarga `google-services.json` a `android/app/google-services.json`.
4. Configura FlutterFire: `dart pub global activate flutterfire_cli`, luego `flutterfire configure --platforms=android`. Este paso configura los plugins nativos y genera `lib/firebase_options.dart` si corresponde. La inicialización `Firebase.initializeApp()` del ejemplo utiliza configuración Android nativa de Firebase; si la herramienta requiere opciones explícitas, cambia a `Firebase.initializeApp(options: DefaultFirebaseOptions.currentPlatform)` e importa `firebase_options.dart`.
5. En Firebase Console activa Authentication > Sign-in method > Email/Password, crea Firestore y Storage, y publica el contenido de `firestore.rules` y `storage.rules` en sus respectivas secciones de Rules. No uses reglas abiertas en producción.
6. En `android/app/src/main/AndroidManifest.xml`, dentro de `<manifest>` y antes de `<application>`, agrega:
   ```xml
   <uses-permission android:name="android.permission.INTERNET" />
   <uses-permission android:name="android.permission.CAMERA" />
   <uses-permission android:name="android.permission.RECORD_AUDIO" />
   <uses-permission android:name="android.permission.MODIFY_AUDIO_SETTINGS" />
   ```
7. Verifica que el `minSdk` de Android sea al menos 23 (o superior si lo exigen las versiones resueltas de plugins). Ejecuta `flutter pub get`, `flutter run`.
8. Para generar APK de prueba: `flutter build apk --debug`; queda en `build/app/outputs/flutter-apk/app-debug.apk`. Para distribución se requiere firma release.

## Pruebas
1. Registra una cuenta A en el teléfono A y otra cuenta B en el teléfono B.
2. En la lista de personas abre B desde A, envía texto, imagen, video y audio.
3. Comprueba que B recibe los mensajes. Para probar llamadas, deja B en la pantalla principal de usuarios, inicia llamada desde A y acepta el aviso entrante en B.
4. Prueba en redes Wi-Fi y móviles distintas. WebRTC usa un servidor STUN público, pero algunas redes NAT estrictas requieren servidor TURN propio para conectar.

## Alcance y limitaciones importantes
- Es un **prototipo de código fuente**, no un APK compilado ni un producto listo para producción. No se ha ejecutado una compilación Flutter en este entorno.
- Los videos se envían pero la pantalla de reproducción muestra un enlace copiable; falta integrar `video_player` para reproducirlos dentro de la aplicación.
- Las llamadas entrantes solo aparecen cuando la pantalla principal está abierta; para notificaciones en segundo plano y teléfono bloqueado se necesita Firebase Cloud Messaging, servicio de notificaciones y manejo de llamadas del sistema.
- El código de señalización de llamadas es inicial; puede presentar condiciones de carrera con ICE y requiere mejoras de reconexión, control de estados, limpieza y TURN.
- No incluye cifrado de extremo a extremo, bloqueo de usuarios, controles antispam, políticas de retención ni auditoría de seguridad. Firebase protege transporte y acceso mediante reglas, pero eso NO equivale a cifrado de extremo a extremo.
- Para producción, endurecer reglas de Firestore y Storage, validar tipos/tamaños de archivo, controlar cuotas, revisar índices y limitar costos.
- Si Flutter informa incompatibilidad entre versiones de paquetes, ejecutar `flutter pub outdated` y ajustar versiones compatibles con el Flutter SDK instalado.
