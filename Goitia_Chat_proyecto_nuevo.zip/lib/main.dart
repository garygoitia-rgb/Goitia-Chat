import 'dart:io';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:firebase_core/firebase_core.dart';
import 'package:firebase_storage/firebase_storage.dart';
import 'package:flutter/material.dart';
import 'package:flutter_webrtc/flutter_webrtc.dart';
import 'package:image_picker/image_picker.dart';
import 'package:just_audio/just_audio.dart';
import 'package:path_provider/path_provider.dart';
import 'package:record/record.dart';
import 'package:uuid/uuid.dart';

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();
  await Firebase.initializeApp();
  runApp(const GoitiaApp());
}

final db = FirebaseFirestore.instance;
final auth = FirebaseAuth.instance;
final storage = FirebaseStorage.instance;

class GoitiaApp extends StatelessWidget {
  const GoitiaApp({super.key});
  @override
  Widget build(BuildContext context) => MaterialApp(
    title: 'Goitia Chat', debugShowCheckedModeBanner: false,
    theme: ThemeData(colorScheme: ColorScheme.fromSeed(seedColor: const Color(0xFF087F63)), useMaterial3: true),
    home: StreamBuilder<User?>(stream: auth.authStateChanges(), builder: (context, snap) {
      if (snap.connectionState == ConnectionState.waiting) return const Scaffold(body: Center(child: CircularProgressIndicator()));
      return snap.data == null ? const LoginPage() : const PeoplePage();
    }),
  );
}

class LoginPage extends StatefulWidget {
  const LoginPage({super.key});
  @override
  State<LoginPage> createState() => _LoginPageState();
}
class _LoginPageState extends State<LoginPage> {
  final email = TextEditingController(), password = TextEditingController(), name = TextEditingController();
  bool signup = false, busy = false;
  Future<void> submit() async {
    setState(() => busy = true);
    try {
      if (signup) {
        final cred = await auth.createUserWithEmailAndPassword(email: email.text.trim(), password: password.text);
        await cred.user!.updateDisplayName(name.text.trim());
        await db.collection('users').doc(cred.user!.uid).set({'name': name.text.trim(), 'email': email.text.trim()});
      } else {
        await auth.signInWithEmailAndPassword(email: email.text.trim(), password: password.text);
      }
    } catch (e) {
      if (mounted) ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('$e')));
    } finally { if (mounted) setState(() => busy = false); }
  }
  @override
  Widget build(BuildContext context) => Scaffold(body: Center(child: SingleChildScrollView(child: ConstrainedBox(constraints: const BoxConstraints(maxWidth: 420), child: Padding(padding: const EdgeInsets.all(24), child: Column(mainAxisSize: MainAxisSize.min, children: [
    const Icon(Icons.forum, size: 70, color: Color(0xFF087F63)),
    const Text('Goitia Chat', style: TextStyle(fontSize: 30, fontWeight: FontWeight.bold)),
    if (signup) TextField(controller: name, decoration: const InputDecoration(labelText: 'Nombre')),
    TextField(controller: email, keyboardType: TextInputType.emailAddress, decoration: const InputDecoration(labelText: 'Correo electrónico')),
    TextField(controller: password, obscureText: true, decoration: const InputDecoration(labelText: 'Contraseña (mínimo 6 caracteres)')),
    const SizedBox(height: 18),
    FilledButton(onPressed: busy ? null : submit, child: Text(signup ? 'Crear cuenta' : 'Ingresar')),
    TextButton(onPressed: () => setState(() => signup = !signup), child: Text(signup ? 'Ya tengo cuenta' : 'Crear una cuenta')),
  ]))))));
}

String roomId(String a, String b) { final ids = [a,b]..sort(); return ids.join('_'); }

class PeoplePage extends StatelessWidget {
  const PeoplePage({super.key});
  @override
  Widget build(BuildContext context) => Scaffold(
    appBar: AppBar(title: const Text('Goitia Chat'), actions: [IconButton(onPressed: () => auth.signOut(), icon: const Icon(Icons.logout))]),
    body: Column(children: [const IncomingCallBanner(), Expanded(child: StreamBuilder<QuerySnapshot<Map<String,dynamic>>>(stream: db.collection('users').snapshots(), builder: (context, snap) {
      if (snap.hasError) return Center(child: Text('Error: ${snap.error}'));
      if (!snap.hasData) return const Center(child: CircularProgressIndicator());
      final people = snap.data!.docs.where((u) => u.id != auth.currentUser!.uid).toList();
      if (people.isEmpty) return const Center(child: Text('Crea una segunda cuenta en otro teléfono para comenzar.'));
      return ListView(children: people.map((u) => ListTile(
        leading: const CircleAvatar(child: Icon(Icons.person)),
        title: Text('${u.data()['name'] ?? 'Usuario'}'), subtitle: Text('${u.data()['email'] ?? ''}'),
        onTap: () => Navigator.push(context, MaterialPageRoute(builder: (_) => ChatPage(peerId: u.id, peerName: '${u.data()['name'] ?? 'Usuario'}'))),
      )).toList());
    }))]),
  );
}

class IncomingCallBanner extends StatelessWidget {
  const IncomingCallBanner({super.key});
  @override
  Widget build(BuildContext context) => StreamBuilder<QuerySnapshot<Map<String,dynamic>>>(
    stream: db.collection('calls').where('callee', isEqualTo: auth.currentUser!.uid).where('status', isEqualTo: 'ringing').snapshots(),
    builder: (context, snap) {
      if (!snap.hasData || snap.data!.docs.isEmpty) return const SizedBox.shrink();
      final call = snap.data!.docs.first; final d = call.data();
      return Card(child: ListTile(title: const Text('Llamada entrante'), subtitle: Text(d['video'] == true ? 'Videollamada' : 'Llamada de voz'),
        trailing: Wrap(children: [IconButton(icon: const Icon(Icons.call_end, color: Colors.red), onPressed: () => call.reference.update({'status':'ended'})),
        IconButton(icon: const Icon(Icons.call, color: Colors.green), onPressed: () => Navigator.push(context, MaterialPageRoute(builder: (_) => CallPage(roomId: call.id, peerId: d['caller'], video: d['video'] == true, caller: false))))]));
    },
  );
}

class ChatPage extends StatefulWidget {
  final String peerId, peerName;
  const ChatPage({super.key, required this.peerId, required this.peerName});
  @override
  State<ChatPage> createState() => _ChatPageState();
}
class _ChatPageState extends State<ChatPage> {
  final input = TextEditingController();
  final recorder = AudioRecorder();
  final player = AudioPlayer();
  bool recording = false, uploading = false;
  late final String id;
  @override
  void initState() { super.initState(); id = roomId(auth.currentUser!.uid, widget.peerId); }
  CollectionReference<Map<String,dynamic>> get messages => db.collection('chats').doc(id).collection('messages');
  Future<void> send(String type, String content) async {
    if (content.trim().isEmpty) return;
    await messages.add({'sender': auth.currentUser!.uid, 'type': type, 'content': content, 'createdAt': FieldValue.serverTimestamp()});
  }
  Future<void> upload(XFile file, String type) async {
    setState(() => uploading = true);
    try {
      final ref = storage.ref('chats/$id/${const Uuid().v4()}_${file.name}');
      await ref.putFile(File(file.path));
      await send(type, await ref.getDownloadURL());
    } catch (e) { if (mounted) ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('No se pudo enviar: $e'))); }
    finally { if (mounted) setState(() => uploading = false); }
  }
  Future<void> pick(ImageSource source, bool video) async {
    final picker = ImagePicker();
    final file = video ? await picker.pickVideo(source: source, maxDuration: const Duration(minutes: 5)) : await picker.pickImage(source: source, imageQuality: 75);
    if (file != null) await upload(file, video ? 'video' : 'image');
  }
  Future<void> toggleRecording() async {
    if (recording) {
      final path = await recorder.stop();
      setState(() => recording = false);
      if (path != null) await upload(XFile(path), 'audio');
    } else {
      if (!await recorder.hasPermission()) return;
      final dir = await getTemporaryDirectory();
      final path = '${dir.path}/${const Uuid().v4()}.m4a';
      await recorder.start(const RecordConfig(encoder: AudioEncoder.aacLc), path: path);
      setState(() => recording = true);
    }
  }
  @override
  void dispose() { input.dispose(); recorder.dispose(); player.dispose(); super.dispose(); }
  @override
  Widget build(BuildContext context) => Scaffold(
    appBar: AppBar(title: Text(widget.peerName), actions: [
      IconButton(tooltip: 'Llamada de voz', icon: const Icon(Icons.call), onPressed: () => Navigator.push(context, MaterialPageRoute(builder: (_) => CallPage(roomId: id, peerId: widget.peerId, video: false, caller: true)))),
      IconButton(tooltip: 'Videollamada', icon: const Icon(Icons.videocam), onPressed: () => Navigator.push(context, MaterialPageRoute(builder: (_) => CallPage(roomId: id, peerId: widget.peerId, video: true, caller: true)))),
    ]),
    body: Column(children: [
      Expanded(child: StreamBuilder<QuerySnapshot<Map<String,dynamic>>>(stream: messages.orderBy('createdAt', descending: true).snapshots(), builder: (context, snap) {
        if (!snap.hasData) return const Center(child: CircularProgressIndicator());
        return ListView(reverse: true, padding: const EdgeInsets.all(12), children: snap.data!.docs.map((m) {
          final data = m.data(), mine = data['sender'] == auth.currentUser!.uid;
          final type = data['type'] as String? ?? 'text', content = data['content'] as String? ?? '';
          Widget body;
          if (type == 'image') { body = Image.network(content, width: 220, errorBuilder: (_, __, ___) => const Text('No se pudo cargar la foto')); }
          else if (type == 'audio') { body = TextButton.icon(onPressed: () async { await player.setUrl(content); await player.play(); }, icon: const Icon(Icons.play_arrow), label: const Text('Reproducir audio')); }
          else if (type == 'video') { body = TextButton.icon(onPressed: () => Navigator.push(context, MaterialPageRoute(builder: (_) => VideoMessagePage(url: content))), icon: const Icon(Icons.movie), label: const Text('Abrir video')); }
          else { body = Text(content); }
          return Align(alignment: mine ? Alignment.centerRight : Alignment.centerLeft, child: Container(margin: const EdgeInsets.symmetric(vertical: 4), padding: const EdgeInsets.all(12), constraints: const BoxConstraints(maxWidth: 280), decoration: BoxDecoration(color: mine ? const Color(0xFFD2F5E8) : const Color(0xFFEDEDED), borderRadius: BorderRadius.circular(16)), child: body));
        }).toList());
      })),
      if (uploading) const LinearProgressIndicator(),
      SafeArea(child: Row(children: [
        PopupMenuButton<String>(icon: const Icon(Icons.attach_file), onSelected: (v) => pick(v == 'camera' ? ImageSource.camera : ImageSource.gallery, v == 'video'), itemBuilder: (_) => const [PopupMenuItem(value: 'photo', child: Text('Foto de galería')), PopupMenuItem(value: 'camera', child: Text('Tomar foto')), PopupMenuItem(value: 'video', child: Text('Video de galería'))]),
        Expanded(child: TextField(controller: input, decoration: const InputDecoration(hintText: 'Escribe un mensaje…', border: InputBorder.none))),
        IconButton(icon: Icon(recording ? Icons.stop_circle : Icons.mic, color: recording ? Colors.red : null), onPressed: toggleRecording),
        IconButton(icon: const Icon(Icons.send), onPressed: () { final text = input.text; input.clear(); send('text', text); }),
      ])),
    ]),
  );
}

// Los videos se abren con el reproductor Android mediante un enlace externo.
// Para una experiencia integrada se puede añadir video_player en una iteración posterior.
class VideoMessagePage extends StatelessWidget {
  final String url;
  const VideoMessagePage({super.key, required this.url});
  @override
  Widget build(BuildContext context) => Scaffold(appBar: AppBar(title: const Text('Video recibido')), body: Center(child: SelectableText('Enlace al video:\n$url\n\nCopia el enlace y ábrelo en el navegador.')));
}

class CallPage extends StatefulWidget {
  final String roomId, peerId;
  final bool video, caller;
  const CallPage({super.key, required this.roomId, required this.peerId, required this.video, required this.caller});
  @override
  State<CallPage> createState() => _CallPageState();
}
class _CallPageState extends State<CallPage> {
  RTCPeerConnection? pc;
  MediaStream? local;
  final localRenderer = RTCVideoRenderer(), remoteRenderer = RTCVideoRenderer();
  final subscriptions = <dynamic>[];
  bool connected = false;
  late DocumentReference<Map<String,dynamic>> callRef;
  @override
  void initState() { super.initState(); start(); }
  Future<void> start() async {
    try {
      await localRenderer.initialize(); await remoteRenderer.initialize();
      local = await navigator.mediaDevices.getUserMedia({'audio': true, 'video': widget.video});
      localRenderer.srcObject = local;
      pc = await createPeerConnection({'iceServers': [{'urls': 'stun:stun.l.google.com:19302'}]});
      for (final track in local!.getTracks()) { await pc!.addTrack(track, local!); }
      pc!.onTrack = (event) { if (event.streams.isNotEmpty) { remoteRenderer.srcObject = event.streams.first; if (mounted) setState(() => connected = true); } };
      callRef = db.collection('calls').doc(widget.roomId);
      final offerCandidates = callRef.collection('offerCandidates');
      final answerCandidates = callRef.collection('answerCandidates');
      pc!.onIceCandidate = (c) { if (c.candidate != null) { (widget.caller ? offerCandidates : answerCandidates).add(c.toMap()); } };
      if (widget.caller) {
        // Eliminar señalización antigua antes de iniciar una llamada nueva.
        for (final collection in [offerCandidates, answerCandidates]) {
          final old = await collection.get(); for (final doc in old.docs) { await doc.reference.delete(); }
        }
        await callRef.set({'caller': auth.currentUser!.uid, 'callee': widget.peerId, 'video': widget.video, 'status': 'ringing', 'createdAt': FieldValue.serverTimestamp()});
        final offer = await pc!.createOffer(); await pc!.setLocalDescription(offer);
        await callRef.update({'offer': offer.toMap()});
        subscriptions.add(callRef.snapshots().listen((snapshot) async {
          final data = snapshot.data(); if (data == null || pc == null) return;
          if (data['status'] == 'ended') { if (mounted) Navigator.pop(context); return; }
          if (data['answer'] != null && await pc!.getRemoteDescription() == null) {
            final a = data['answer'] as Map<String,dynamic>;
            await pc!.setRemoteDescription(RTCSessionDescription(a['sdp'], a['type']));
          }
        }));
        subscriptions.add(answerCandidates.snapshots().listen((s) { for (final change in s.docChanges) { if (change.type == DocumentChangeType.added && pc != null) { final c = change.doc.data()!; pc!.addCandidate(RTCIceCandidate(c['candidate'], c['sdpMid'], c['sdpMLineIndex'])); } } }));
      } else {
        final data = (await callRef.get()).data()!;
        final offer = data['offer'] as Map<String,dynamic>;
        await pc!.setRemoteDescription(RTCSessionDescription(offer['sdp'], offer['type']));
        final answer = await pc!.createAnswer(); await pc!.setLocalDescription(answer);
        await callRef.update({'answer': answer.toMap(), 'status': 'accepted'});
        subscriptions.add(offerCandidates.snapshots().listen((s) { for (final change in s.docChanges) { if (change.type == DocumentChangeType.added && pc != null) { final c = change.doc.data()!; pc!.addCandidate(RTCIceCandidate(c['candidate'], c['sdpMid'], c['sdpMLineIndex'])); } } }));
        subscriptions.add(callRef.snapshots().listen((s) { if (s.data()?['status'] == 'ended' && mounted) Navigator.pop(context); }));
      }
    } catch (e) { if (mounted) ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('Error de llamada: $e'))); }
  }
  Future<void> hangup() async { try { await callRef.update({'status': 'ended'}); } catch (_) {} if (mounted) Navigator.pop(context); }
  @override
  void dispose() {
    for (final sub in subscriptions) { sub.cancel(); }
    for (final track in local?.getTracks() ?? <MediaStreamTrack>[]) { track.stop(); }
    pc?.close(); localRenderer.dispose(); remoteRenderer.dispose(); super.dispose();
  }
  @override
  Widget build(BuildContext context) => Scaffold(backgroundColor: Colors.black, appBar: AppBar(title: Text(widget.video ? 'Videollamada' : 'Llamada de voz')), body: Column(children: [
    Expanded(child: widget.video ? Stack(children: [RTCVideoView(remoteRenderer, objectFit: RTCVideoViewObjectFit.RTCVideoViewObjectFitCover), Positioned(right: 12, top: 12, width: 110, height: 160, child: RTCVideoView(localRenderer, mirror: true))]) : Center(child: Icon(connected ? Icons.call : Icons.call_outlined, color: Colors.white, size: 90))),
    const SizedBox(height: 12), Text(connected ? 'Conectado' : 'Conectando…', style: const TextStyle(color: Colors.white)),
    Padding(padding: const EdgeInsets.all(24), child: FilledButton.icon(style: FilledButton.styleFrom(backgroundColor: Colors.red), onPressed: hangup, icon: const Icon(Icons.call_end), label: const Text('Colgar'))),
  ]));
}
